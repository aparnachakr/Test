package com.example.mavenarkfirstproj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MavenArkFirstProjApplicationTests {

    @Test
    void contextLoads() {
    }

}
