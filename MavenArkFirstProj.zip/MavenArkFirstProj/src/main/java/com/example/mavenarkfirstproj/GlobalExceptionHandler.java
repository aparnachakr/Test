package com.example.mavenarkfirstproj;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<AiResponse> handleValidationExceptions(
            MethodArgumentNotValidException ex) {

        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach(error -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });

        AiResponse response = AiResponse.builder()
                .success(false)
                .error("Validation failed: " + errors.toString())
                .timestamp(LocalDateTime.now())
                .requestId(UUID.randomUUID().toString())
                .build();

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
    }

    @ExceptionHandler(OpenAiServiceException.class)
    public ResponseEntity<AiResponse> handleOpenAiServiceException(
            OpenAiServiceException ex) {

        log.error("OpenAI Service Exception: {}", ex.getMessage(), ex);

        AiResponse response = AiResponse.builder()
                .success(false)
                .error(ex.getMessage())
                .timestamp(LocalDateTime.now())
                .requestId(UUID.randomUUID().toString())
                .build();

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<AiResponse> handleGeneralException(Exception ex) {
        log.error("Unexpected exception: {}", ex.getMessage(), ex);

        AiResponse response = AiResponse.builder()
                .success(false)
                .error("An unexpected error occurred: " + ex.getMessage())
                .timestamp(LocalDateTime.now())
                .requestId(UUID.randomUUID().toString())
                .build();

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
    }
}
