package com.example.mavenarkfirstproj;


import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class OpenAiService {

    private final WebClient webClient;
    private final OpenAiConfig config;

    public Mono<AiResponse> generateResponse(PromptRequest request) {
        String requestId = UUID.randomUUID().toString();
        log.debug("Processing request {} with prompt: {}", requestId, request.getPrompt());

        try {
            OpenAiApiRequest apiRequest = buildApiRequest(request);

            return webClient.post()
                    .uri(config.getUrl())
                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + config.getKey())
                    .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                    .bodyValue(apiRequest)
                    .retrieve()
                    .bodyToMono(OpenAiApiResponse.class)
                    .map(apiResponse -> buildSuccessResponse(apiResponse, requestId))
                    .onErrorResume(WebClientResponseException.class,
                            e -> handleWebClientError(e, requestId))
                    .onErrorResume(Exception.class,
                            e -> handleGeneralError(e, requestId));

        } catch (Exception e) {
            log.error("Error building API request for {}: {}", requestId, e.getMessage(), e);
            return Mono.just(buildErrorResponse(e.getMessage(), requestId));
        }
    }

    private OpenAiApiRequest buildApiRequest(PromptRequest request) {
        List<OpenAiApiRequest.Message> messages = new ArrayList<>();

        // Add system message if provided
        if (request.getSystemMessage() != null && !request.getSystemMessage().isBlank()) {
            messages.add(OpenAiApiRequest.Message.builder()
                    .role("system")
                    .content(request.getSystemMessage())
                    .build());
        }

        // Add user prompt
        messages.add(OpenAiApiRequest.Message.builder()
                .role("user")
                .content(request.getPrompt())
                .build());

        return OpenAiApiRequest.builder()
                .model(request.getModel() != null ? request.getModel() : config.getModel())
                .messages(messages)
                .maxTokens(request.getMaxTokens() != null ?
                        request.getMaxTokens() : config.getMaxTokens())
                .temperature(request.getTemperature() != null ?
                        request.getTemperature() : config.getTemperature())
                .build();
    }

    private AiResponse buildSuccessResponse(OpenAiApiResponse apiResponse, String requestId) {
        String content = apiResponse.getChoices() != null &&
                !apiResponse.getChoices().isEmpty() ?
                apiResponse.getChoices().get(0).getMessage().getContent() : "";

        AiResponse.UsageInfo usageInfo = null;
        if (apiResponse.getUsage() != null) {
            usageInfo = AiResponse.UsageInfo.builder()
                    .promptTokens(apiResponse.getUsage().getPromptTokens())
                    .completionTokens(apiResponse.getUsage().getCompletionTokens())
                    .totalTokens(apiResponse.getUsage().getTotalTokens())
                    .build();
        }

        return AiResponse.builder()
                .success(true)
                .response(content)
                .model(apiResponse.getModel())
                .usage(usageInfo)
                .timestamp(LocalDateTime.now())
                .requestId(requestId)
                .build();
    }

    private Mono<AiResponse> handleWebClientError(WebClientResponseException e, String requestId) {
        log.error("OpenAI API error for request {}: Status={}, Body={}",
                requestId, e.getStatusCode(), e.getResponseBodyAsString());

        String errorMessage = String.format("OpenAI API error: %s - %s",
                e.getStatusCode(), e.getResponseBodyAsString());

        return Mono.just(buildErrorResponse(errorMessage, requestId));
    }

    private Mono<AiResponse> handleGeneralError(Exception e, String requestId) {
        log.error("Unexpected error for request {}: {}", requestId, e.getMessage(), e);
        return Mono.just(buildErrorResponse("Internal error: " + e.getMessage(), requestId));
    }

    private AiResponse buildErrorResponse(String errorMessage, String requestId) {
        return AiResponse.builder()
                .success(false)
                .error(errorMessage)
                .timestamp(LocalDateTime.now())
                .requestId(requestId)
                .build();
    }
}