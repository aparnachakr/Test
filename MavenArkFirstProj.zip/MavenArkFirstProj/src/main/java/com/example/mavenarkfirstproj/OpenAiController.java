package com.example.mavenarkfirstproj;


import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

@Slf4j
@RestController
@RequestMapping("/api/v1/ai")
@RequiredArgsConstructor
public class OpenAiController {

    private final OpenAiService openAiService;

    @PostMapping("/prompt")
    public Mono<ResponseEntity<AiResponse>> processPrompt(
            @Valid @RequestBody PromptRequest request) {

        log.info("Received prompt request: {}", request.getPrompt());

        return openAiService.generateResponse(request)
                .map(response -> {
                    HttpStatus status = response.isSuccess() ?
                            HttpStatus.OK : HttpStatus.INTERNAL_SERVER_ERROR;
                    return ResponseEntity.status(status).body(response);
                });
    }

    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("Service is running");
    }
}